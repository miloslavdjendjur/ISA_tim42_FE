import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../../../posts/auth.service';
@Component({
  selector: 'app-activation',
  templateUrl: './activation.component.html',
  styleUrls: ['./activation.component.css']
})
export class ActivationComponent implements OnInit {
  activationMessage: string = '';
  isError: boolean = false;

  constructor(
    private route: ActivatedRoute,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    const token = this.route.snapshot.queryParamMap.get('token');
    console.log("Token received from URL:", token); // Log token for verification
  
    if (token) {
      this.authService.activateAccount(token).subscribe(
        (response: any) => {
          console.log("Success Response:", response); // Log the success response from backend
          this.activationMessage = response.message || 'Account activated successfully.';
          this.isError = false;
        },
        (error: any) => {
          console.log("Error Response:", error); // Log the error response from backend
          if (error.status === 400 && error.error && error.error.error) {
            this.activationMessage = error.error.error;
          } else {
            this.activationMessage = 'Invalid or expired activation token.';
          }
          this.isError = true;
        }
      );             
    } else {
      this.activationMessage = 'Invalid activation link.';
      this.isError = true;
    }
  }
  
  
}
